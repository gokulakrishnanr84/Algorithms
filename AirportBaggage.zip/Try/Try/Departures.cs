﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirportBaggage
{
    public class Departures : IInputReader
    {
        private Queue<string> _lines;

        private Dictionary<string, FlightDetails> _departuresList;

        public Departures()
        {
            _departuresList = new Dictionary<string, FlightDetails>();

            _lines = new Queue<string>(
                        new List<string>
                        {
                            "UA10 A1 MIA 08:00",
                            "UA11 A1 LAX 09:00",
                            "UA12 A1 JFK 09:45",
                            "UA13 A2 JFK 08:30",
                            "UA14 A2 JFK 09:45",
                            "UA15 A2 JFK 10:00",
                            "UA16 A3 JFK 09:00",
                            "UA17 A4 MHT 09:15",
                            "UA18 A5 LAX 10:15"
                        });
        }

        public bool CanRead
        {
            get
            {
                return _lines.Count > 0;
            }
        }

        public string ReadLine()
        {
            return _lines.Dequeue();
        }

        public Dictionary<string, FlightDetails> DeparturesList
        {
            get
            {
                while (_lines.Count > 0)
                {
                    var details = ReadLine().Split(' ');
                    _departuresList.Add(details[FlightDetails.FlightId],
                        new FlightDetails
                        {
                            Gate = details.Length > 1 ? details[FlightDetails.FlightGate] : string.Empty,
                            Destination = details.Length > 2 ? details[FlightDetails.FlightDestination] : string.Empty,
                            DepartureTime = details.Length > 3 ? details[FlightDetails.FlightDeparture] : string.Empty
                        });
                }
                _departuresList.Add(FlightDetails.ARRIVAL, new FlightDetails { Gate = FlightDetails.ARRIVAL_GATE });
                return _departuresList;
            }
        }
    }
    
    public class FlightDetails
    {
        public static readonly int FlightId = 0;
        public static readonly int FlightGate = 1;
        public static readonly int FlightDestination = 2;
        public static readonly int FlightDeparture = 3;
        public static readonly string ARRIVAL = "ARRIVAL";
        public static readonly string ARRIVAL_GATE = "BaggageClaim";

        public string Gate { get; set; }
        public string Destination { get; set; }
        public string DepartureTime { get; set; }
    }
}
