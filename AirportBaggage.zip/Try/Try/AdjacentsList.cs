﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirportBaggage
{
    public class AdjacentsList
    {
        public Dictionary<string, Dictionary<string, int>> AdjLists { get; }

        public AdjacentsList()
        {
            AdjLists = new Dictionary<string, Dictionary<string, int>>();
        }

        public void AddNodes(string inputLines)
        {
            var details = inputLines.Split(' ');
            var node = details.Length > 0 ? details[0] : string.Empty;
            var adjacent = details.Length > 1 ? details[1] : string.Empty;
            var weight = details.Length > 2 ? int.Parse(details[2]) : 0;

            FormAdjacents(node, adjacent, weight);
            FormAdjacents(adjacent, node, weight);
        }

        private void FormAdjacents(string node, string adjacent, int weight)
        {
            if (AdjLists.ContainsKey(node))
            {
                var lists = AdjLists[node];
                lists.Add(adjacent, weight);
                AdjLists[node] = lists;
            }
            else
            {
                var list = new Dictionary<string, int>();
                list[adjacent] = weight;
                AdjLists[node] = list;
            }
        }

        public PrintDetails FindShortestPath(string start, string flightNumber)
        {
            var pathDetails = new PrintDetails();
            var departuresList = new Departures().DeparturesList;
            var finish = departuresList[flightNumber].Gate;

            var previous = new Dictionary<string, string>();
            var distances = new Dictionary<string, int>();
            var nodes = new List<string>();

            List<string> path = null;

            foreach (var vertex in AdjLists)
            {
                if (vertex.Key == start)
                {
                    distances[vertex.Key] = 0;
                }
                else
                {
                    distances[vertex.Key] = int.MaxValue;
                }

                nodes.Add(vertex.Key);
            }

            while (nodes.Count != 0)
            {
                nodes.Sort((x, y) => distances[x] - distances[y]);

                var smallest = nodes[0];
                nodes.Remove(smallest);

                if (smallest == finish)
                {
                    path = new List<string>();
                    while (previous.ContainsKey(smallest))
                    {
                        path.Add(smallest);
                        smallest = previous[smallest];
                    }

                    path.Add(start);
                    break;
                }

                if (distances[smallest] == int.MaxValue)
                {
                    break;
                }

                foreach (var neighbor in AdjLists[smallest])
                {
                    var alt = distances[smallest] + neighbor.Value;
                    if (alt < distances[neighbor.Key])
                    {
                        distances[neighbor.Key] = alt;
                        previous[neighbor.Key] = smallest;
                    }
                }
            }
            
            pathDetails.ReversePath = path;
            pathDetails.Distance = distances[finish];
            return pathDetails;
        }
    }

    public class PrintDetails
    {
        public string BagNumber { get; set; }
        public int Distance { get; set; }
        public List<string> ReversePath { get; set; }
    }
}
