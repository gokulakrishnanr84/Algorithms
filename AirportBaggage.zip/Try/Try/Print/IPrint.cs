﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirportBaggage.Output
{
    public interface IPrint
    {
        void Print(PrintDetails path);
    }
}
