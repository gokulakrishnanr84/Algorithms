﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirportBaggage.Output
{
    public class Print
    {
        public void PrintDetails(IPrint printType, PrintDetails output)
        {
            printType.Print(output);
        }
    }

    internal class PrintConsole : IPrint
    {
        public void Print(PrintDetails output)
        {
            Console.Write("{0} ", output.BagNumber);
            List<string> actualPath = output.ReversePath;
            actualPath.Reverse();
            actualPath.ForEach(item => Console.Write(item + " "));
            Console.Write(" : {0} \n", output.Distance);
        }
    }

    internal class PrintFile : IPrint
    {
        public void Print(PrintDetails path)
        {
            throw new NotImplementedException();
        }
    }

    internal class PrintDB : IPrint
    {
        public void Print(PrintDetails path)
        {
            throw new NotImplementedException();
        }
    }
}
