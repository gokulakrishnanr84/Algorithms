﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirportBaggage.Output;

namespace AirportBaggage
{
    class Program
    {
        static void Main(string[] args)
        {
            var conveyorSystem = new ConveyorSystem();
            var departures = new Departures();
            var bags = new Baggage();

            var adjacentList = new AdjacentsList();
            while(conveyorSystem.CanRead)
            {
                adjacentList.AddNodes(conveyorSystem.ReadLine());
            }

            while(bags.CanRead)
            {
                var input = bags.ReadLine().Split(' ');
                var printDetails = adjacentList.FindShortestPath(input[Baggage.Entry], input[Baggage.FlightNumber]);
                printDetails.BagNumber = input[Baggage.BagNumber];

                var print = new Print();
                print.PrintDetails(new PrintConsole(), printDetails);
            }
        }
    }
}
