﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirportBaggage
{
    public class Baggage : IInputReader
    {
        public static readonly int BagNumber = 0;
        public static readonly int Entry = 1;
        public static readonly int FlightNumber = 2;

        private Queue<string> _lines;

        public Baggage()
        {
            _lines = new Queue<string>(
                        new List<string>
                        {
                            "0001 Concourse_A_Ticketing UA12",
                            "0002 A5 UA17",
                            "0003 A2 UA10",
                            "0004 A8 UA18",
                            "0005 A7 ARRIVAL"
                        });
        }

        public bool CanRead
        {
            get
            {
                return _lines.Count > 0;
            }
        }

        public string ReadLine()
        {
            return _lines.Dequeue();
        }
    }
}
